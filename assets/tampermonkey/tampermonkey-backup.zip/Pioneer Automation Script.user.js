// ==UserScript==
// @name         Pioneer Automation Script
// @namespace    http://tampermonkey.net/
// @version      1.1
// @description  Automates Pioneer workflow with new keybind
// @match        *pioneer.sewerai.com/dashboard/review*
// @grant        GM_notification
// @grant        GM_addStyle
// ==/UserScript==

(function() {
    'use strict';

    document.addEventListener('keydown', async function(e) {
        // Use Alt+Shift+G for Pioneer automation
        if (e.altKey && e.shiftKey && e.key === 'G') {
            e.preventDefault();
            await runPioneerWorkflow();
        }
    });

    async function runPioneerWorkflow() {
        try {
            showAlert("🚀 Starting Pioneer workflow...");

            // 1. Click the first button
            const firstBtn = await waitForClickable('button.hide-small-screen:nth-child(1)');
            if (!firstBtn) {
                showAlert("⚠️ Couldn't find first button!");
                return;
            }
            firstBtn.click();
            console.log("Clicked first button");
            await delay(1000);

            // 2. Click the bp5-button
            const bp5Btn = await waitForClickable('a.bp5-button');
            if (!bp5Btn) {
                showAlert("⚠️ Couldn't find bp5-button!");
                return;
            }
            bp5Btn.click();
            console.log("Clicked bp5-button");
            await delay(3000); // Wait longer for page to load

            // 3. Click the blue row item (try multiple selectors)
            const blueRowSelectors = [
                'tr.border-l-8:nth-child(1) > td:nth-child(13) > div:nth-child(1) > a:nth-child(1)',
                'tr.border-l-8:nth-child(1) > td:nth-child(13) > div:nth-child(1) > a:nth-child(1)'
            ];

            let blueRowItem = null;
            for (const selector of blueRowSelectors) {
                blueRowItem = await waitForClickable(selector, 100); // Shorter timeout per selector
                if (blueRowItem) {
                    console.log(`Found blue row item with selector: ${selector}`);
                    break;
                }
            }

            if (!blueRowItem) {
                showAlert("⚠️ Couldn't find blue row item with any selector!");
                return;
            }
            blueRowItem.click();
            console.log("Clicked blue row item");

            // 4. Wait for player buttons to appear and check play/pause button
            const playPauseBtn = await waitForElement('#playerButtons > div:nth-child(1) > div:nth-child(3) > button:nth-child(1)', 10000);
            if (!playPauseBtn) {
                showAlert("⚠️ Player buttons didn't appear!");
                return;
            }

            // Check if aria-label says "Pause" and click only if it does
            const ariaLabel = playPauseBtn.getAttribute('aria-label');
            if (ariaLabel === 'Pause') {
                playPauseBtn.click();
                console.log("Clicked pause button");
                await delay(300);
            } else {
                console.log("Button aria-label is:", ariaLabel, "- not clicking");
            }

            // 5. Click the speed control button
            const speedBtn = await waitForClickable('button.hover\\:bg-blue-3:nth-child(13)');
            if (!speedBtn) {
                showAlert("⚠️ Couldn't find speed button!");
                return;
            }
            speedBtn.click();
            console.log("Clicked speed button");
            await delay(300);

            // 6. Select from dropdown
            const dropdown = await waitForElement('.bg-white', 3000);
            if (!dropdown || dropdown.tagName !== 'SELECT') {
                showAlert("⚠️ Couldn't find speed dropdown!");
                return;
            }

            // Find the 6th option and update its value to "4"
            const option6th = document.querySelector('.bg-white > option:nth-child(6)');
            if (option6th) {
                option6th.value = '4';
                option6th.textContent = '4x';
                console.log("Updated 6th option value to 4");
            }

            // Find the 7th option and update its value to "5"
            const option7th = document.querySelector('.bg-white > option:nth-child(7)');
            if (option7th) {
                option7th.value = '5';
                option7th.textContent = '5x';
                console.log("Updated 7th option value to 5");
            }

            // Find the 8th option and update its value to "8"
            const option8th = document.querySelector('.bg-white > option:nth-child(8)');
            if (option8th) {
                option8th.value = '8';
                option8th.textContent = '8x';
                console.log("Updated 8th option value to 8");
            }


            // Find the 9th option and update its value to "15"
            const option9th = document.querySelector('.bg-white > option:nth-child(9)');
            if (option9th) {
                option9th.value = '15';
                option9th.textContent = '15x';
                console.log("Updated 9th option value to 15");
            }

            // Find the 6x option and select it (or use the updated value if that's what you want)
            const optionToSelect = Array.from(dropdown.options).find(opt => opt.value === '5');
            if (!optionToSelect) {
                showAlert("⚠️ Couldn't find the desired option!");
                return;
            }

            dropdown.value = optionToSelect.value;
            dropdown.dispatchEvent(new Event('change', {bubbles: true}));
            dropdown.dispatchEvent(new Event('input', {bubbles: true}));
            console.log(`Selected ${optionToSelect.value}x speed`);

            // 7. Click the target button after dropdown change
            await delay(500); // Wait a bit for the dropdown change to take effect
            const targetBtn = await waitForClickable('#playerButtons > div:nth-child(1) > div:nth-child(5) > button:nth-child(1)');
            if (!targetBtn) {
                showAlert("⚠️ Couldn't find target button after dropdown change!");
                return;
            }
            targetBtn.click();
            console.log("Clicked target button after dropdown change");

            showAlert("✅ Pioneer workflow completed successfully!");

        } catch (err) {
            console.error("Pioneer workflow failed:", err);
            showAlert("❌ Error: " + err.message);
        }
    }

    // Helper functions
    function waitForClickable(selector, timeout = 5000) {
        return new Promise((resolve) => {
            const start = Date.now();
            const check = () => {
                const el = document.querySelector(selector);
                if (el && isVisible(el) && !el.disabled) {
                    resolve(el);
                } else if (Date.now() - start > timeout) {
                    resolve(null);
                } else {
                    setTimeout(check, 200);
                }
            };
            check();
        });
    }

    function waitForElement(selector, timeout = 5000) {
        return new Promise((resolve) => {
            const start = Date.now();
            const check = () => {
                const el = document.querySelector(selector);
                if (el) {
                    resolve(el);
                } else if (Date.now() - start > timeout) {
                    resolve(null);
                } else {
                    setTimeout(check, 200);
                }
            };
            check();
        });
    }

    function isVisible(el) {
        const style = window.getComputedStyle(el);
        return !!(el.offsetWidth || el.offsetHeight || el.getClientRects().length) &&
               style.visibility !== 'hidden' &&
               style.display !== 'none' &&
               style.opacity !== '0';
    }

    function showAlert(message) {
        GM_notification({
            title: "Pioneer Automation",
            text: message,
            timeout: 3000
        });
    }

    function delay(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    console.log("Pioneer Automation Script loaded - Use Alt+Shift+G to run");
})();