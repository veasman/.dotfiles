// ==UserScript==
// @name         Pioneer Video Info Helper
// @namespace    nodal
// @version      1.0.0
// @description  On review pages, reads Summary fields and injects them into the top action/info bar right after the "Uploaded" pill.
// @match        https://pioneer.sewerai.com/*
// @run-at       document-idle
// @grant        GM_getValue
// @grant        GM_setValue
// ==/UserScript==

(() => {
    "use strict";

    const SELECTORS = {
        lateral: "#Summary-Lateral_Segment_Reference",
        us: "#Summary-Upstream_MH",
        ds: "#Summary-Downstream_MH",
        len: "#Summary-Length_Surveyed",
    };

    const ROUTE_RE = /^\/dashboard\/review\/([0-9a-fA-F-]{36})(.*)?$/;

    const STORAGE_PREFIX = "sewerai:review:summary:";

    function sleep(ms) {
        return new Promise(r => setTimeout(r, ms));
    }

    function isReviewRoute() {
        const m = window.location.pathname.match(ROUTE_RE);
        return m ? {
            uuid: m[1],
            rest: m[2] || ""
        } : null;
    }

    function norm(v) {
        return (v ?? "").toString().trim();
    }

    function getInputValue(sel) {
        const el = document.querySelector(sel);
        if (!el) return {
            el: null,
            value: ""
        };
        // Works for input/textarea; if it’s something else, fall back to textContent
        const v = "value" in el ? el.value : el.textContent;
        return {
            el,
            value: norm(v)
        };
    }

    function findElementWithExactText(root, texts) {
        // Searches small set of likely candidates first for speed; then broader.
        const candidates = root.querySelectorAll("button, a, div, span");
        const want = new Set(texts.map(t => t.trim()));
        for (const el of candidates) {
            const t = norm(el.textContent);
            if (want.has(t)) return el;
        }
        return null;
    }

    function createChip() {
        const chip = document.createElement("div");
        chip.id = "tm-lateral-summary-chip";

        chip.className = "inline-flex items-center gap-2";
        chip.style.height = "25px";
        chip.style.padding = "0 8px";
        chip.style.borderRadius = "4px";
        chip.style.border = "1px solid rgba(255,255,255,0.16)";
        chip.style.background = "rgba(255,255,255,0.05)";
        chip.style.color = "rgba(231,237,245,0.95)";
        chip.style.fontSize = "13px";
        chip.style.lineHeight = "32px";
        chip.style.letterSpacing = "0.25px";
        chip.style.whiteSpace = "nowrap";

        chip.style.cursor = "default";
        chip.style.userSelect = "text";

        const label = document.createElement("span");
        label.className = "tm-chip-label";
        label.style.color = "rgba(154,167,182,0.95)";
        label.style.fontWeight = "600";

        const value = document.createElement("span");
        value.id = "tm-lateral-summary-chip-value";
        value.className = "tm-chip-value";
        value.style.fontWeight = "600";
        value.style.color = "rgba(231,237,245,0.98)";
        value.textContent = "—";

        chip.appendChild(label);
        chip.appendChild(value);

        chip.addEventListener("mouseenter", () => {
            chip.style.background = "rgba(255,255,255,0.095)";
            chip.style.borderColor = "rgba(255,255,255,0.22)";
        });
        chip.addEventListener("mouseleave", () => {
            chip.style.background = "rgba(255,255,255,0.07)";
            chip.style.borderColor = "rgba(255,255,255,0.16)";
        });

        return chip;
    }

    function titleToken(t) {
        if (!t) return "";
        // Preserve single-letter unit tokens like "A", "B", "C"
        if (/^[A-Z]$/.test(t)) return t;
        // Keep common all-caps abbreviations if any slip through
        if (/^[A-Z]{2,}$/.test(t)) return t;
        return t.charAt(0).toUpperCase() + t.slice(1).toLowerCase();
    }

    function normalizeStreetType(t) {
        const k = (t || "").replace(/[.,]/g, "").toLowerCase();
        const map = {
            st: "St",
            street: "St",
            ave: "Ave",
            avenue: "Ave",
            rd: "Rd",
            road: "Rd",
            dr: "Dr",
            drive: "Dr",
            blvd: "Blvd",
            boulevard: "Blvd",
            ln: "Ln",
            lane: "Ln",
            ct: "Ct",
            court: "Ct",
            cir: "Cir",
            circle: "Cir",
            pkwy: "Pkwy",
            parkway: "Pkwy",
            pl: "Pl",
            place: "Pl",
            ter: "Ter",
            terrace: "Ter",
            trl: "Trl",
            trail: "Trl",
            way: "Way",
            hwy: "Hwy",
            highway: "Hwy",
            sq: "Sq",
            square: "Sq",
        };
        return map[k] || null;
    }

    function isCardinal(t) {
        return /^(N|E|S|W)$/i.test((t || "").replace(/[.,]/g, ""));
    }

    function shortenMH(raw) {
        // Examples:
        // "MH 313 Main St"               -> "313 Main St"
        // "MH 313 C Main St"             -> "313 C Main St"
        // "STMH 3008 E Road Center Valley"-> "3008 Road Center Rd"
        // "STMH 101 B N Red Birch Way"   -> "101 B Red Birch Way"
        if (!raw) return "";

        // Tokenize and strip obvious prefixes
        const tokens = raw
            .trim()
            .split(/\s+/)
            .map(t => t.replace(/[^\w.]/g, "")) // light cleanup
            .filter(Boolean)
            .filter(t => !/^(MH|STMH)$/i.test(t)); // remove leading tags anywhere

        if (!tokens.length) return raw.trim();

        // Find first numeric token as house number
        const numIdx = tokens.findIndex(t => /^\d+$/.test(t));
        if (numIdx === -1) return raw.trim();

        const num = tokens[numIdx];
        let i = numIdx + 1;

        // Optional unit letter immediately after number (A/B/C)
        let unit = "";
        if (i < tokens.length && /^[A-Z]$/.test(tokens[i])) {
            unit = tokens[i];
            i++;
        }

        // Optional cardinal direction after number or unit letter
        if (i < tokens.length && isCardinal(tokens[i])) i++;

        // Collect street name tokens until we hit a street type
        const streetName = [];
        let streetType = "";

        for (; i < tokens.length; i++) {
            const t = tokens[i];
            const normType = normalizeStreetType(t);
            if (normType) {
                streetType = normType;
                break;
            }
            streetName.push(titleToken(t));
        }

        // Special case: no street type found, but pattern like "... Road Center Valley"
        // Your requirement claims a type always exists, but your example contradicts it.
        // Heuristic: if no type, and we have a "Road" token in the name, drop the last token
        // (often a locality like "Valley") and append "Rd".
        if (!streetType) {
            const hasRoadToken = streetName.some(x => x.toLowerCase() === "road");
            if (hasRoadToken && streetName.length >= 2) {
                // Drop last token (e.g., "Valley") and add Rd
                streetName.pop();
                streetType = "Rd";
            }
        }

        // Build final
        const parts = [num];
        if (unit) parts.push(unit);
        if (streetName.length) parts.push(...streetName);
        if (streetType) parts.push(streetType);

        return parts.join(" ").trim();
    }

    function normalizeLength(raw) {
        if (!raw) return "";
        const n = raw.match(/[\d.]+/);
        return n ? `${n[0]} ft` : raw.trim();
    }

    function stripCardinalBeforeStreet(lateralRaw) {
        // Removes a standalone N/E/S/W token that appears right before the street name token.
        // Keeps things like "North St" and "N St" (since in those cases the token after N is a street type).
        if (!lateralRaw) return "";

        const s = lateralRaw.trim();

        // Common street-type tokens (so we can keep "N St", "E Ave", etc.)
        const streetTypes = new Set([
            "st", "street", "ave", "avenue", "rd", "road", "dr", "drive", "blvd", "boulevard", "ln", "lane", "ct", "court",
            "cir", "circle", "pkwy", "parkway", "pl", "place", "ter", "terrace", "trl", "trail", "way", "hwy", "highway",
            "sq", "square", "expy", "expressway"
        ]);

        // Tokenize preserving punctuation minimally
        const parts = s.split(/\s+/);
        if (parts.length < 3) return s; // not enough structure to matter

        // Find patterns like: "<number> <N|E|S|W> <streetName> ..."
        // The key rule: direction token must be standalone, and next token must NOT be a street type.
        for (let i = 1; i < parts.length - 1; i++) {
            const dir = parts[i].replace(/[.,]/g, "");
            if (!/^(N|E|S|W)$/i.test(dir)) continue;

            const next = (parts[i + 1] || "").replace(/[.,]/g, "").toLowerCase();

            // If next token is a street type ("St", "Ave", etc.), then this is "N St" and must stay.
            if (streetTypes.has(next)) continue;

            // Also preserve "North", "East", etc. (not a single-letter cardinal)
            // (Already handled because dir must be single-letter.)

            // Remove the direction token
            parts.splice(i, 1);
            return parts.join(" ");
        }

        return s;
    }

    function hasSpelledOutCardinal(raw) {
        if (!raw) return false;
        return /\b(North|South|East|West)\b/i.test(raw);
    }

    function formatDisplay(data) {
        if (data.lateral) {
            return {
                label: "Lat:",
                text: stripCardinalBeforeStreet(data.lateral)
            };
        }

        if (data.us && data.ds && data.len) {
            const usRaw = data.us;
            const dsRaw = data.ds;

            const us = shortenMH(usRaw);
            const ds = shortenMH(dsRaw);
            const len = normalizeLength(data.len);

            // If upstream contains a fully spelled-out cardinal direction,
            // assume it is actually a direction note and show it last.
            if (hasSpelledOutCardinal(usRaw)) {
                return {
                    label: "US/DS:",
                    text: `${ds} • ${len} → ${usRaw.trim()}`
                };
            }

            return {
                label: "US/DS:",
                text: `${us} → ${ds} • ${len}`
            };
        }

        return null;
    }

    function readSummaryFields() {
        const lateral = getInputValue(SELECTORS.lateral).value;

        if (lateral) {
            return {
                lateral,
                us: "",
                ds: "",
                len: ""
            };
        }

        const us = getInputValue(SELECTORS.us).value;
        const ds = getInputValue(SELECTORS.ds).value;
        const len = getInputValue(SELECTORS.len).value;
        return {
            lateral: "",
            us,
            ds,
            len
        };
    }

    function attachLiveListeners(onChange) {
        const els = [
            document.querySelector(SELECTORS.lateral),
            document.querySelector(SELECTORS.us),
            document.querySelector(SELECTORS.ds),
            document.querySelector(SELECTORS.len),
        ].filter(Boolean);

        for (const el of els) {
            el.addEventListener("input", onChange, {
                passive: true
            });
            el.addEventListener("change", onChange, {
                passive: true
            });
        }
    }

    function upsertIntoTopBar(displayText, displayLabel) {
        let chip = document.getElementById("tm-lateral-summary-chip");
        if (!chip) chip = createChip();

        const labelEl = chip.querySelector(".tm-chip-label") || chip.firstChild;
        const valueEl = chip.querySelector("#tm-lateral-summary-chip-value");

        // Use the label we pass in (Lat: vs US/DS:)
        labelEl.textContent = displayLabel || "Ref:";
        valueEl.textContent = displayText || "—";

        // Find the "Uploaded" pill and insert right after its containing div
        const uploadedEl = findElementWithExactText(document, ["Uploaded"]);
        if (!uploadedEl) return false;

        const uploadedContainer = uploadedEl.closest("div") || uploadedEl.parentElement;
        if (!uploadedContainer || !uploadedContainer.parentElement) return false;

        const parent = uploadedContainer.parentElement;

        if (chip.parentElement !== parent) {
            parent.insertBefore(chip, uploadedContainer.nextSibling);
        } else {
            if (uploadedContainer.nextSibling !== chip) {
                parent.insertBefore(chip, uploadedContainer.nextSibling);
            }
        }

        return true;
    }

    async function waitForAnySelector(selectors, timeoutMs = 15000) {
        const start = Date.now();
        while (Date.now() - start < timeoutMs) {
            for (const sel of selectors) {
                if (document.querySelector(sel)) return true;
            }
            await sleep(200);
        }
        return false;
    }

    async function runForPage(uuid) {
        // Avoid duplicate observers/loops
        window.__tmSewerAIActive = true;

        // Wait until at least one of the Summary inputs exists (SPA + async render)
        await waitForAnySelector(
            [SELECTORS.lateral, SELECTORS.us, SELECTORS.ds, SELECTORS.len],
            20000
        );

        const storageKey = `${STORAGE_PREFIX}${uuid}`;

        const update = () => {
            const data = readSummaryFields();
            const formatted = formatDisplay(data);

            if (formatted) {
                GM_setValue(storageKey, formatted);
                upsertIntoTopBar(formatted.text, formatted.label);
                return;
            }

            // If fields aren’t populated yet, try last known value for this UUID
            const cached = GM_getValue(storageKey, null);
            if (cached && cached.text && cached.label) {
                upsertIntoTopBar(cached.text, cached.label);
            }
        };

        // Initial update + a few retries to catch the top bar arriving late
        for (let i = 0; i < 40; i++) {
            update();
            // Stop early if we successfully inserted the chip
            if (document.getElementById("tm-lateral-summary-chip")?.isConnected) break;
            await sleep(250);
        }

        // Live updates when you type/change fields
        attachLiveListeners(update);

        // Also watch DOM for SPA rerenders that might remove the top bar and recreate it
        const mo = new MutationObserver(() => {
            // If the chip is missing but we have cached/current data, re-insert.
            if (!document.getElementById("tm-lateral-summary-chip")) update();
        });
        mo.observe(document.documentElement, {
            childList: true,
            subtree: true
        });

        // Store so we can disconnect on route change
        window.__tmSewerAIMutationObserver = mo;
    }

    function cleanupIfNeeded() {
        if (window.__tmSewerAIMutationObserver) {
            try {
                window.__tmSewerAIMutationObserver.disconnect();
            } catch { }
            window.__tmSewerAIMutationObserver = null;
        }
        window.__tmSewerAIActive = false;
    }

    async function main() {
        let lastHref = "";

        while (true) {
            const href = window.location.href;

            if (href !== lastHref) {
                lastHref = href;
                cleanupIfNeeded();

                const route = isReviewRoute();
                if (route) {
                    runForPage(route.uuid);
                }
            }

            await sleep(500);
        }
    }

    main();
})();