// ==UserScript==
// @name         GIS Form Autofill
// @namespace    http://tampermonkey.net/
// @version      1.9
// @description  Clicks Edit, scrolls, pastes URL, adds date, and selects QC Name
// @match        https://editor.giscloud.com*
// @grant        GM_notification
// @grant        GM_addStyle
// @grant        unsafeWindow
// ==/UserScript==

(function() {
    'use strict';

    // Add some styles to help with scrolling visibility
    GM_addStyle(`
        #custom-form-window {
            scroll-behavior: smooth !important;
        }
    `);

    document.addEventListener('keydown', async function(e) {
        if (e.ctrlKey && e.shiftKey && e.key === 'V') {
            await runFullWorkflow();
        }
    });

    async function runFullWorkflow() {
        try {
            // 1. Click Edit Attributes button
            const editBtn = await waitForClickable('#infotab_formeditlink .btn-default:first-child');
            if (!editBtn) {
                showAlert("⚠️ Couldn't find Edit button!");
                return;
            }
            editBtn.click();
            console.log("Clicked Edit button");

            // 2. Wait for dialog
            const dialog = await waitForElement('#custom-form-window', 10000);
            if (!dialog) {
                showAlert("⚠️ Dialog didn't appear!");
                return;
            }

            // 3. Scroll to bottom PROPERLY
            const scrollableContainer = dialog.querySelector('div > div > div') || dialog;
            scrollableContainer.scrollTo({
                top: scrollableContainer.scrollHeight,
                behavior: 'smooth'
            });
            await delay(1000);

            // NEW: 4. Select "Pass" radio for QC Pass/Fail (Video)
            await selectRadioButton('input[id^="radio_QC_Pass_Fail__Video__"][value="Pass"]');

            // NEW: 5. Fill QC Comments with "PASS-CAM"
            await fillTextarea('textarea[id^="text_QC_Comments_"]', 'PASS-CAM');

            // NEW: 6. Select "Yes" radio for Property Cleared
            await selectRadioButton('input[id^="radio_Property_Cleared_"][value="Yes"]');

            // 7. Fill QC Date with today's date
            const today = new Date();

            // Try multiple selectors for the date field
            let dateInput = await waitForElement('input[id^="text_QC_Date_"]');
            let dateFormat = 'short'; // Default format: MM/DD/YY

            if (!dateInput) {
                // Try alternative selector for datetime input field
                dateInput = await waitForElement('input[id^="datetime_QC_Date_"]');
                if (dateInput) {
                    dateFormat = 'long'; // Use full year format for datetime inputs
                }
            }

            if (!dateInput) {
                // Try the complex nested selector pattern
                const datetimeContainer = await waitForElement('div[id^="datetime_QC_Date_"]');
                if (datetimeContainer) {
                    dateInput = datetimeContainer.querySelector('input');
                    if (dateInput) {
                        dateFormat = 'long'; // Use full year format for datetime inputs
                    }
                }
            }

            if (dateInput) {
                let formattedDate;
                if (dateFormat === 'long') {
                    // Format as MM/DD/YYYY for datetime inputs
                    formattedDate = `${String(today.getMonth() + 1).padStart(2, '0')}/${String(today.getDate()).padStart(2, '0')}/${today.getFullYear()}`;
                } else {
                    // Format as MM/DD/YY for text inputs
                    formattedDate = `${String(today.getMonth() + 1).padStart(2, '0')}/${String(today.getDate()).padStart(2, '0')}/${String(today.getFullYear()).slice(-2)}`;
                }

                dateInput.value = formattedDate;
                dateInput.dispatchEvent(new Event('input', {bubbles: true}));
                dateInput.dispatchEvent(new Event('change', {bubbles: true}));
                console.log("Date filled:", formattedDate, "(Format:", dateFormat + ")");
            } else {
                console.log("QC Date field not found");
                showAlert("⚠️ Couldn't find QC Date field!");
            }

            // 8. Select "Charlton Moren" from dropdown
            await selectDropdownOption('select[id^="select_QC_Name_"]', "Charlton Moren");

            // 9. Find and focus VIDEO URL field
            const videoInput = await waitForElement('input[id^="text_VIDEO_URL_"]');
            if (!videoInput) {
                showAlert("⚠️ VIDEO URL field missing!");
                return;
            }

            // Bring element into view and focus
            videoInput.scrollIntoView({behavior: 'smooth', block: 'center'});
            await delay(500);
            videoInput.focus();
            await delay(100);

            // 10. DIRECT PASTE using Ctrl+V simulation on the target field
            // Clear the field first
            videoInput.value = '';
            videoInput.select();

            // Create and dispatch a paste event directly on the input field
            const pasteEvent = new ClipboardEvent('paste', {
                bubbles: true,
                cancelable: true,
                clipboardData: null
            });

            // Focus the input and simulate Ctrl+V
            videoInput.focus();
        } catch (err) {
            console.error("Workflow failed:", err);
            showAlert("❌ Error: " + err.message);
        }
    }

    // NEW: Helper function to select radio buttons
    async function selectRadioButton(selector) {
        const radio = await waitForElement(selector);
        if (!radio) {
            console.log("Radio button not found:", selector);
            return false;
        }

        // Check if it's already selected
        if (!radio.checked) {
            radio.checked = true;

            // Trigger events to ensure the change is registered
            radio.dispatchEvent(new Event('change', {bubbles: true}));
            radio.dispatchEvent(new Event('click', {bubbles: true}));
            radio.dispatchEvent(new Event('input', {bubbles: true}));

            console.log("Selected radio button:", selector);
        } else {
            console.log("Radio button already selected:", selector);
        }

        return true;
    }

    // NEW: Helper function to fill textarea
    async function fillTextarea(selector, text) {
        const textarea = await waitForElement(selector);
        if (!textarea) {
            console.log("Textarea not found:", selector);
            return false;
        }

        textarea.value = text;

        // Trigger events to ensure the change is registered
        textarea.dispatchEvent(new Event('input', {bubbles: true}));
        textarea.dispatchEvent(new Event('change', {bubbles: true}));

        console.log("Filled textarea with:", text);
        return true;
    }

    // Try multiple methods to trigger paste on the focused element
    async function tryMultiplePasteMethods(element) {
        // Method 1: Simulate Ctrl+V keydown/keyup
        try {
            element.focus();
            element.select();

            const keydownEvent = new KeyboardEvent('keydown', {
                key: 'v',
                code: 'KeyV',
                ctrlKey: true,
                bubbles: true,
                cancelable: true
            });

            const keyupEvent = new KeyboardEvent('keyup', {
                key: 'v',
                code: 'KeyV',
                ctrlKey: true,
                bubbles: true,
                cancelable: true
            });

            element.dispatchEvent(keydownEvent);
            await delay(50);
            element.dispatchEvent(keyupEvent);
            await delay(200);

            if (element.value.trim() !== '') {
                console.log("Paste successful via Method 1");
                return true;
            }
        } catch (e) {
            console.log("Method 1 failed:", e);
        }

        // Method 2: Use execCommand paste on focused element
        try {
            element.focus();
            element.select();
            const success = document.execCommand('paste');
            await delay(200);

            if (success && element.value.trim() !== '') {
                console.log("Paste successful via Method 2");
                return true;
            }
        } catch (e) {
            console.log("Method 2 failed:", e);
        }

        // Method 3: Create temporary textarea and transfer content
        try {
            const tempTextarea = document.createElement('textarea');
            tempTextarea.style.position = 'absolute';
            tempTextarea.style.left = '-9999px';
            tempTextarea.contentEditable = true;
            document.body.appendChild(tempTextarea);

            tempTextarea.focus();
            tempTextarea.select();

            // Try to paste into temp textarea
            document.execCommand('paste');
            await delay(200);

            if (tempTextarea.value.trim() !== '') {
                element.value = tempTextarea.value;
                element.dispatchEvent(new Event('input', {bubbles: true}));
                element.dispatchEvent(new Event('change', {bubbles: true}));
                document.body.removeChild(tempTextarea);
                console.log("Paste successful via Method 3");
                return true;
            }

            document.body.removeChild(tempTextarea);
        } catch (e) {
            console.log("Method 3 failed:", e);
        }

        return false;
    }

    // Wait for user to manually paste content
    async function waitForManualPaste(element) {
        return new Promise((resolve) => {
            const originalValue = element.value;
            let attempts = 0;
            const maxAttempts = 150; // 30 seconds timeout

            const checkForContent = () => {
                attempts++;
                if (element.value !== originalValue && element.value.trim() !== '') {
                    console.log("Manual paste detected");
                    resolve(true);
                } else if (attempts >= maxAttempts) {
                    console.log("Manual paste timeout");
                    resolve(false);
                } else {
                    setTimeout(checkForContent, 200);
                }
            };

            // Also listen for paste event
            const pasteListener = () => {
                setTimeout(() => {
                    if (element.value.trim() !== '') {
                        element.removeEventListener('paste', pasteListener);
                        resolve(true);
                    }
                }, 100);
            };

            element.addEventListener('paste', pasteListener);
            checkForContent();
        });
    }

    // Helper function to select dropdown option
    async function selectDropdownOption(selector, optionText) {
        const dropdown = await waitForElement(selector);
        if (!dropdown) {
            console.log("Dropdown not found:", selector);
            return false;
        }

        // Find the option
        const option = Array.from(dropdown.options).find(opt => opt.text === optionText);
        if (!option) {
            console.log("Option not found in dropdown:", optionText);
            return false;
        }

        // Change the value
        dropdown.value = option.value;

        // Trigger events
        dropdown.dispatchEvent(new Event('change', {bubbles: true}));
        dropdown.dispatchEvent(new Event('input', {bubbles: true}));

        // Handle Bootstrap Select if present
        const bootstrapSelect = dropdown.nextElementSibling;
        if (bootstrapSelect && bootstrapSelect.classList.contains('bootstrap-select')) {
            const button = bootstrapSelect.querySelector('.dropdown-toggle');
            const span = bootstrapSelect.querySelector('.filter-option');

            if (button) button.setAttribute('title', optionText);
            if (span) span.textContent = optionText;
        }

        console.log("Selected option:", optionText);
        return true;
    }

    // Helper functions
    function waitForClickable(selector, timeout = 5000) {
        return new Promise((resolve) => {
            const start = Date.now();
            const check = () => {
                const el = document.querySelector(selector);
                if (el && isVisible(el) && !el.disabled) resolve(el);
                else if (Date.now() - start > timeout) resolve(null);
                else setTimeout(check, 200);
            };
            check();
        });
    }

    function isVisible(el) {
        const style = window.getComputedStyle(el);
        return !!(el.offsetWidth || el.offsetHeight || el.getClientRects().length) &&
               style.visibility !== 'hidden' &&
               style.display !== 'none' &&
               style.opacity !== '0';
    }

    function waitForElement(selector, timeout = 2000) {
        return new Promise((resolve) => {
            const start = Date.now();
            const check = () => {
                const el = document.querySelector(selector);
                if (el) resolve(el);
                else if (Date.now() - start > timeout) resolve(null);
                else setTimeout(check, 200);
            };
            check();
        });
    }

    function showAlert(message) {
        GM_notification({
            title: "GIS Autofill",
            text: message,
            timeout: 3000
        });
    }

    function delay(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }
})();