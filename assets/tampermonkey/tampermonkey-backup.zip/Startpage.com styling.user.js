// ==UserScript==
// @name         Startpage.com styling
// @namespace    https://startpage.com/
// @version      1.1
// @description  Styling changes to startpage.com
// @match        https://startpage.com/
// @match        https://www.startpage.com/
// @run-at       document-end
// ==/UserScript==

(function () {
    'use strict';

    function sendEscape() {
        const evt = new KeyboardEvent('keydown', {
            key: 'Escape',
            code: 'Escape',
            keyCode: 27,
            which: 27,
            bubbles: true,
            cancelable: true
        });

        document.dispatchEvent(evt);
    }

    function applyStyles() {
        const homeInner = document.querySelector('.search-home-inner');
        const formContainer = document.querySelector('.search-form-container');

        if (homeInner) {
            homeInner.style.marginTop = '15%';
        }

        if (formContainer) {
            formContainer.style.borderColor = 'rgb(120, 140, 200)';
        }

        if (homeInner && formContainer) {
            sendEscape();
        } else {
            setTimeout(applyStyles, 100);
        }
    }

    applyStyles();
})();